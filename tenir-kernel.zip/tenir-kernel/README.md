# tenir-kernel — Governance Kernel (Tier 1)

A minimal, independently deployable reference implementation of the TENIR-Gov admissibility formula.

**No external database required.** One YAML file, one endpoint, eight tests.

---

## What this is

`tenir-kernel` is Tier 1 of the TENIR-Gov two-tier architecture. It implements the core governance invariant:

```
S = K / (P × V + ε)
```

where **P** = Pressure, **V** = Velocity, **K** = Capacity, **ε** = numerical stabilization parameter.

Three verdicts are produced:

| Score range | Verdict | Full middleware equivalent |
|:------------|:-------:|:--------------------------:|
| S ≥ 0.90 | `PASS` | `allow` |
| 0.75 ≤ S < 0.90 | `FLAG` | `allow_with_alert` |
| S < 0.75 | `HARD_VETO` | `block` |

Thresholds are configured in `tenir_policies.yaml` and mirror the R5 full middleware defaults.

---

## Quick start

```bash
pip install -r requirements.txt
pytest tests/ -v          # 8/8 kernel tests (K1–K8)
./run.sh                  # FastAPI server on :8000
```

**Single adjudication request:**

```bash
curl -X POST http://localhost:8000/api/v1/adjudicate \
  -H "Content-Type: application/json" \
  -d '{"actor_id": "op-1", "action_context": "deploy-model",
       "p": 0.70, "v": 0.85, "k": 0.50}'
```

---

## Structure

```
tenir-kernel/
├── core/
│   ├── policy_engine.py   # S = K/(P×V+ε); PASS/FLAG/HARD_VETO verdicts
│   └── ledger.py          # append-only SHA-256 Merkle chain
├── api/
│   └── server.py          # FastAPI /adjudicate endpoint + WebSocket stream
├── data/                  # ledger output directory (created at runtime)
├── tests/
│   └── test_tenir_kernel.py  # K1–K8: formula, verdicts, epsilon, chain integrity
├── tenir_policies.yaml    # ε=1e-6, hard_veto=0.75, flag=0.90
├── requirements.txt
└── run.sh
```

---

## Kernel validation tests (K1–K8)

| Test | What it verifies |
|:-----|:-----------------|
| K1 | `PASS` verdict when S ≥ flag_below |
| K2 | `FLAG` verdict when hard_veto_below ≤ S < flag_below |
| K3 | `HARD_VETO` verdict when S < hard_veto_below |
| K4 | Epsilon guard prevents ZeroDivisionError when P=V=0 |
| K5 | S = K/(P×V+ε) to 6 decimal places |
| K6 | Identical inputs produce identical outputs (determinism) |
| K7 | Ledger chain hash is independently reproducible; prev_hash links entries |
| K8 | Every JSONL entry carries timestamp, prev_hash, payload, hash (64-char SHA-256) |

Run: `pytest tests/ -v` from this directory.

---

## Policy configuration

```yaml
# tenir_policies.yaml
parameters:
  epsilon: 0.000001      # canonical R5 value; zero-division guard

thresholds:
  hard_veto_below: 0.75  # ≡ s_block_floor in tenir_governance (R5 default)
  flag_below:      0.90  # ≡ s_alert_floor in tenir_governance (R5 default)
```

**Epsilon note:** the canonical default (1e-6) is a numerical guard, semantically
negligible at operationally realistic P×V values. Institutional deployments may
specify ε = 0.01 as a semantic damping factor; this must be declared in the
institution's Rulebook YAML and cited in every audit trace.

---

## Relationship to full middleware

| Property | `tenir-kernel` | `tenir_governance` |
|:---------|:--------------:|:------------------:|
| Formula | ✓ | ✓ |
| Epsilon | 1e-6 (canonical) | 1e-6 (canonical) |
| Thresholds | YAML configurable | YAML + PolicyConfig dataclass |
| Verdict names | PASS / FLAG / HARD_VETO | allow / allow_with_alert / block |
| External DB | None | Neo4j 5.x |
| NSL parser | ✗ | ✓ |
| Admin plane | ✗ | ✓ |
| Tests | 8 (K1–K8) | 549 (547 passing, 2 skipped) |

The kernel is a correct, independently testable subset of the full middleware —
not a simplified approximation. It is suitable for embedded deployments, edge
environments, educational use, and architectural verification.

---

## Part of TENIR-Gov R5.0.0 (IRON OMEGA R5)

Repository: https://github.com/skiredj-prog/tenir-gov  
Full middleware: `tenir_governance/`  
License: Apache License 2.0  
DOI: 10.5281/zenodo.10823456
