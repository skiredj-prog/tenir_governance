import json
import time
import hashlib
import asyncio
from pathlib import Path

class GovernanceLedger:
    """
    Registre Append-Only. Trace inaltérable des décisions du moteur.
    """
    def __init__(self, path: str = "data/governance_ledger.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.last_hash = "GENESIS_V6"
        
        # Initialiser le fichier s'il n'existe pas
        if not self.path.exists():
            self.path.touch()
        else:
            # Récupérer le dernier hash pour la continuité de la chaîne
            with open(self.path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                if lines:
                    try:
                        last_record = json.loads(lines[-1])
                        self.last_hash = last_record.get('hash', "GENESIS_V6")
                    except:
                        pass

    def append_entry(self, record_data: dict) -> dict:
        record = {
            "timestamp": time.time(),
            "prev_hash": self.last_hash,
            "payload": record_data
        }
        
        # Hachage déterministe
        record_str = json.dumps(record, sort_keys=True)
        self.last_hash = hashlib.sha256(record_str.encode('utf-8')).hexdigest()
        record["hash"] = self.last_hash
        
        # Écriture atomique (Append)
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(record) + '\n')
            
        return record

    async def stream_tail(self):
        """
        Générateur asynchrone pour diffuser les nouvelles entrées via WebSocket.
        """
        with open(self.path, 'r', encoding='utf-8') as f:
            # Aller à la fin du fichier
            f.seek(0, 2)
            while True:
                line = f.readline()
                if not line:
                    await asyncio.sleep(0.1)
                    continue
                yield line
