"""
tenir-kernel / tests / test_tenir_kernel.py
=============================================
Kernel validation suite — 8 targeted tests (K1–K8).

Thresholds align with R5 tenir_governance default policy:
  hard_veto_below = 0.75  (≡ s_block_floor)
  flag_below      = 0.90  (≡ s_alert_floor)
  epsilon         = 1e-6  (canonical R5 zero-division guard)

Run from the tenir-kernel/ directory:
    pytest tests/ -v
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import pytest

POLICY_FILE = Path(__file__).parent.parent / "tenir_policies.yaml"

# Ensure kernel core is importable
sys.path.insert(0, str(Path(__file__).parent.parent))


def make_engine():
    from core.policy_engine import PolicyEngine
    return PolicyEngine(POLICY_FILE)


# ── Verdict coverage (K1–K3) ─────────────────────────────────────────────────

class TestPolicyEngineVerdicts:
    """All three admissibility branches must be reachable and correctly labelled."""

    def test_k1_pass_decision(self):
        """S ≥ flag_below (0.90) → PASS.
        S = 5.0 / (0.2 * 0.2 + 1e-6) ≈ 124.99  >> 0.90
        """
        result = make_engine().evaluate(p=0.2, v=0.2, k=5.0)
        assert result["decision"] == "PASS"
        assert result["s_score"] >= 0.90

    def test_k2_flag_decision(self):
        """hard_veto_below ≤ S < flag_below (0.75 ≤ S < 0.90) → FLAG.
        S = 0.80 / (1.0 * 1.0 + 1e-6) ≈ 0.80 — inside the flag band.
        """
        result = make_engine().evaluate(p=1.0, v=1.0, k=0.80)
        assert result["decision"] == "FLAG"
        assert 0.75 <= result["s_score"] < 0.90

    def test_k3_hard_veto_decision(self):
        """S < hard_veto_below (0.75) → HARD_VETO.
        Banking M&A pattern: S = 0.40 / (0.90 * 0.85 + 1e-6) ≈ 0.52.
        """
        result = make_engine().evaluate(p=0.90, v=0.85, k=0.40)
        assert result["decision"] == "HARD_VETO"
        assert result["s_score"] < 0.75


# ── Formula correctness (K4–K6) ───────────────────────────────────────────────

class TestPolicyEngineFormula:
    def test_k4_epsilon_prevents_zero_division(self):
        """p=0, v=0 → denominator = epsilon → no ZeroDivisionError; S >> 0."""
        result = make_engine().evaluate(p=0.0, v=0.0, k=1.0)
        assert result["decision"] == "PASS"
        assert math.isfinite(result["s_score"])
        assert result["s_score"] > 0

    def test_k5_formula_numerical_correctness(self):
        """S must equal K / (P * V + ε) to 6 decimal places."""
        engine = make_engine()
        p, v, k = 1.5, 0.8, 2.0
        expected = k / (p * v + engine.epsilon)
        result = engine.evaluate(p=p, v=v, k=k)
        assert abs(result["s_score"] - round(expected, 6)) < 1e-9

    def test_k6_determinism(self):
        """Identical inputs on consecutive calls must produce identical output."""
        engine = make_engine()
        r1 = engine.evaluate(p=0.85, v=0.78, k=0.50)
        r2 = engine.evaluate(p=0.85, v=0.78, k=0.50)
        assert r1["s_score"] == r2["s_score"]
        assert r1["decision"] == r2["decision"]


# ── Ledger integrity (K7–K8) ──────────────────────────────────────────────────

class TestGovernanceLedger:
    def _make_ledger(self, tmp_path: Path):
        from core.ledger import GovernanceLedger
        return GovernanceLedger(str(tmp_path / "test_ledger.jsonl"))

    def test_k7_ledger_chain_integrity(self, tmp_path):
        """Each entry's hash must be independently reproducible and chained."""
        ledger = self._make_ledger(tmp_path)
        rec_a = ledger.append_entry({"decision": "PASS", "s_score": 2.50})
        rec_b = ledger.append_entry({"decision": "FLAG", "s_score": 0.82})

        raw_a = json.dumps(
            {k: v for k, v in rec_a.items() if k != "hash"},
            sort_keys=True,
        )
        assert rec_a["hash"] == hashlib.sha256(raw_a.encode()).hexdigest()
        assert rec_b["prev_hash"] == rec_a["hash"]

    def test_k8_ledger_append_only_structure(self, tmp_path):
        """Every written JSONL line must carry all required audit fields."""
        ledger = self._make_ledger(tmp_path)
        required = {"timestamp", "prev_hash", "payload", "hash"}
        for i in range(3):
            ledger.append_entry({"s_score": 1.0 + i * 0.5, "decision": "PASS"})

        ledger_path = tmp_path / "test_ledger.jsonl"
        lines = ledger_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 3
        for idx, line in enumerate(lines):
            entry = json.loads(line)
            missing = required - entry.keys()
            assert not missing, f"Entry {idx} missing: {missing}"
            assert len(entry["hash"]) == 64
            assert all(c in "0123456789abcdef" for c in entry["hash"])
