from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import asyncio
import json

from core.policy_engine import PolicyEngine
from core.ledger import GovernanceLedger

app = FastAPI(
    title="TENIR Core System",
    description="Niveau Zéro de la Stratégie - Moteur d'Admissibilité",
    version="6.0.0"
)

# Autoriser le Flight Deck (Lens V18) à se connecter
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialisation du Sanctuaire
engine = PolicyEngine("tenir_policies.yaml")
ledger = GovernanceLedger("data/governance_ledger.jsonl")

class AdjudicationRequest(BaseModel):
    actor_id: str = Field(..., description="Identifiant de l'opérateur ou du système appelant")
    action_context: str = Field(..., description="Description de l'action tentée")
    p: float = Field(..., description="Pression (ex: volatilité, urgence)")
    v: float = Field(..., description="Vélocité (ex: vitesse d'exécution, fréquence)")
    k: float = Field(..., description="Capacité (ex: liquidité, ressources, résilience)")

@app.post("/api/v1/adjudicate")
async def adjudicate_action(req: AdjudicationRequest):
    """
    Route de Jugement. Évalue l'admissibilité et grave la décision dans le registre.
    """
    # 1. Le moteur calcule (aveugle à l'interface)
    result = engine.evaluate_admissibility(req.p, req.v, req.k)
    
    # 2. Préparation de la trace d'audit
    audit_payload = {
        "actor_id": req.actor_id,
        "action_context": req.action_context,
        "metrics": {"p": req.p, "v": req.v, "k": req.k},
        "evaluation": result
    }
    
    # 3. Gravure dans le registre cryptographique
    saved_record = ledger.append_entry(audit_payload)
    
    return saved_record

@app.websocket("/stream/ledger")
async def websocket_ledger_stream(websocket: WebSocket):
    """
    Flux de Vie. Diffuse les décisions en temps réel pour animer le Flight Deck (Canvas 3D).
    """
    await websocket.accept()
    try:
        async for line in ledger.stream_tail():
            await websocket.send_text(line)
    except Exception as e:
        print(f"WebSocket disconnected: {e}")
