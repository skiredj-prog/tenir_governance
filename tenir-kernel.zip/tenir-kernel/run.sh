#!/bin/bash
echo "Démarrage du TENIR Core System (V6)..."
uvicorn api.server:app --host 0.0.0.0 --port 8000 --reload
